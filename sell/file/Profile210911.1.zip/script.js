// Hiệu ứng di chuột tạo ánh sáng chạy theo (Tilt effect đơn giản)
const buttons = document.querySelectorAll('.glass-btn');

buttons.forEach(btn => {
    btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        btn.style.setProperty('--x', `${x}px`);
        btn.style.setProperty('--y', `${y}px`);
    });
});

// Bạn có thể thêm code đổi màu ngẫu nhiên khi click tại đây
console.log("Profile của Đàm Trọng Nghĩa đã sẵn sàng!");
